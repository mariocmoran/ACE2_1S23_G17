import React, { useState, useEffect, useRef } from "react";
import { getUser } from "./Global.js";
import BarChart from "./graficas/BarChart.js";

import parado from './parado.png'
import sentado from './sentado.png'


function useInterval(callback, delay) {
    const savedCallback = useRef();

    // Remember the latest function.
    useEffect(() => {
        savedCallback.current = callback;
    }, [callback]);

    // Set up the interval.
    useEffect(() => {
        function tick() {
            savedCallback.current();
        }
        if (delay !== null) {
            let id = setInterval(tick, delay);
            return () => clearInterval(id);
        }
    }, [delay]);
}

function Graficas() {

    const [data1, setData1] = useState([]);
    const [data2, setData2] = useState([]);

    const [img, setImg] = useState();
    const [img2, setImg2] = useState();

    const [imgStyle1, setimgStyle1] = useState();
    const [imgStyle2, setimgStyle2] = useState();

    const [data3, setData3] = useState([]);
    const [data4, setData4] = useState([]);

    const [dateInit, setDateInit] = useState("01-01-2023");
    const [dateFin, setDateFin] = useState("12-12-2023");

    const handleSubmit = (event) => {
        event.preventDefault(); // Evita que se recargue la página al enviar el formulario
        if (event.target[0].value !== "" && event.target[1].value !== "") {
            //console.log("working", event.target[0].value, event.target[1].value);  
            setDateInit(event.target[0].value);
            setDateFin(event.target[1].value);
        } else {
            alert("Por favor ingrese ambos parámetros.")
        }

    };

    useInterval(() => {
        fetch(`http://localhost:5000/ultimoData`, {
            method: 'GET',
        })
            .then(res => res.json())
            .catch(err => {
                console.error('Error:', err)
                //alert("Ocurrio un error, ver la consola")
            })
            .then(response => {
                var ndata = [{ name: "", total: response[0].Penalizacion_No_S, init: "", end: "" }]
                setData1(ndata);
                ndata = [{ name: "", total: response[0].Penalizacion_No_P, init: "", end: "" }]
                setData2(ndata);
                if (response[0].Estado) {
                    setImg(parado)
                    setimgStyle1({ width: "80%" })
                } else {
                    setImg(sentado)
                    setimgStyle1({ width: "50%" })
                }

                if (response[0].Sentado_Descanso) {
                    setImg2(parado)
                    setimgStyle2({ width: "80%" })
                } else {
                    setImg2(sentado)
                    setimgStyle2({ width: "50%" })
                }
            })

            fetch(`http://localhost:5000/data?fecha1=${dateInit}&fecha2=${dateFin}`)
            .then(response => response.json())
            .then(data => console.log(data))
            .catch(error => console.error(error))

    }, 1000);

    return (
        <div>
            <p className="fs-5 text-end"> <span className="fw-bold text-end">Usuario:</span> {getUser()}</p>
            <div style={{ width: "95%", margin: "auto", marginTop: "5%", marginBottom: "5%" }}>
                <center><h1>INFORME EN TIEMPO REAL</h1></center>
                <form style={{ width: "30%", margin: "auto", marginTop: "3%" }} onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label className="form-label">Inicio:</label>
                        <input type="date" className="form-control" />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Fin:</label>
                        <input type="date" className="form-control" />
                    </div>
                    <center><button type="submit" className="btn btn-primary">Establecer datos</button></center>
                </form>
                <div className="container" style={{ marginTop: "5%" }}>
                    <div className="row">
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Penalización por no sentarse a tiempo </h4>
                            <BarChart data={data1} name="Penalización" color="red" />
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4> Penalización por no pararse a tiempo</h4>
                            <BarChart data={data2} name="Penalización" color="red" />
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Validación de que el usuario esté sentado </h4>
                            <center><img src={img} alt="Imagen" style={{ maxWidth: "100%", maxHeight: "100%", ...imgStyle1 }} /></center>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Validación de que el usuario no esté sentado</h4>
                            <center><img src={img2} alt="Imagen" style={{ maxWidth: "100%", maxHeight: "100%", ...imgStyle2 }} /></center>
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Porcentajes de cumplimiento</h4>
                            <BarChart data={data3} name="Cumplimiento" />
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Gráfica del total de pomodoros</h4>
                            <BarChart data={data4} name="Pomodoros" />
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}

export default Graficas;