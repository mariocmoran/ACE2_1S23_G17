import { getUser } from "./Global.js";


function Graficas() {
    return (
        <div>
            <p className="fs-5 text-end"> <span className="fw-bold text-end">Usuario:</span> {getUser()}</p>
            <div style={{ width: "95%", margin: "auto", marginTop: "5%" }}>
                <center><h1>INFORME EN TIEMPO REAL</h1></center>
                <div className="container" style={{ marginTop: "5%" }}>
                    <div className="row">
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Penalización por no sentarse a tiempo </h4>
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4> Penalización por no pararse a tiempo</h4>
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Validación de que el usuario esté sentado </h4>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Validación de que el usuario no esté sentado</h4>
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Porcentajes de cumplimiento</h4>
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Gráfica del total de pomodoros</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}

export default Graficas;