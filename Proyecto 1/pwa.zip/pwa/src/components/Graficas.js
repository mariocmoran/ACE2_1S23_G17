import React, { useState, useEffect, useRef } from "react";
import { getUser } from "./Global.js";
import BarChart from "./graficas/BarChart.js";

import parado from './parado.png'
import sentado from './sentado.png'


function useInterval(callback, delay) {
    const savedCallback = useRef();

    // Remember the latest function.
    useEffect(() => {
        savedCallback.current = callback;
    }, [callback]);

    // Set up the interval.
    useEffect(() => {
        function tick() {
            savedCallback.current();
        }
        if (delay !== null) {
            let id = setInterval(tick, delay);
            return () => clearInterval(id);
        }
    }, [delay]);
}

function Graficas() {

    const [data1, setData1] = useState([]);
    const [data2, setData2] = useState([]);

    const [img, setImg] = useState();
    const [img2, setImg2] = useState();

    const [imgStyle1, setimgStyle1] = useState();
    const [imgStyle2, setimgStyle2] = useState();

    const [data3, setData3] = useState([]);
    const [data4, setData4] = useState([]);

    const [dateInit, setDateInit] = useState("2023-01-01");
    const [dateFin, setDateFin] = useState("2023-12-31");

    const handleSubmit = (event) => {
        event.preventDefault(); // Evita que se recargue la página al enviar el formulario
        if (event.target[0].value !== "" && event.target[1].value !== "") {
            //console.log("working", event.target[0].value, event.target[1].value);  
            setDateInit(event.target[0].value);
            setDateFin(event.target[1].value);
        } else {
            alert("Por favor ingrese ambos parámetros.")
        }

    };

    useInterval(() => {
        fetch(`http://localhost:5000/ultimoData`, {
            method: 'GET',
        })
            .then(res => res.json())
            .catch(err => {
                console.error('Error:', err)
                //alert("Ocurrio un error, ver la consola")
            })
            .then(response => {
                var ndata = [{ total: response[0].Penalizacion_No_S, init: "", end: "", name:"Penalización parado" }]
                setData1(ndata);
                ndata = [{ total: response[0].Penalizacion_No_P, init: "", end: "", name:"Penalización sentado" }]
                setData2(ndata);
                if (response[0].Estado === 1) {
                    setImg(parado)
                    setimgStyle1({ width: "80%" })
                    setImg2(parado)
                    setimgStyle2({ width: "80%" })
                } else {
                    setImg(sentado)
                    setimgStyle1({ width: "50%" })
                    setImg2(sentado)
                    setimgStyle2({ width: "50%" })
                }
            })

            fetch(`http://localhost:5000/ultimos4`)
            .then(response => response.json())
            .catch(error => console.error(error))
            .then(data => {
                //console.log(data)

                if (data.length < 4){
                    var ndata = []
                    for (var j = 0; j < data.length; j++){
                        var ps = ((data[j].Penalizacion_No_S/60) / data[j].Tiempo_Trabajo)*100
                        var pp = ((data[j].Penalizacion_No_P/60) / data[j].Tiempo_Trabajo)*100
                        var completo = { total: 100- ps-pp, init: "", end: "", name:"Cumplimiento" }
                        var penS = { total: ps, init: "", end: "", name:"Sentado" }
                        var penP = { total: pp, init: "", end: "", name:"Parado" }
                        ndata.push(completo)
                        ndata.push(penS)
                        ndata.push(penP)
                    }
                    setData3(ndata);
                }else{
                    var cant = data[3].No_Pomodoro
                    var ndata2 = []
                    for (var i = (4-cant); i < 4; i++){
                        var ps2 = ((data[i].Penalizacion_No_S/60) / data[i].Tiempo_Trabajo)*100
                        var pp2 = ((data[i].Penalizacion_No_P/60) / data[i].Tiempo_Trabajo)*100
                        var completo2 = { total: 100- ps2-pp2, init: "", end: "", name:"Cumplimiento" }
                        var penS2 = { total: ps2, init: "", end: "", name:"Sentado" }
                        var penP2 = { total: pp2, init: "", end: "", name:"Parado" }
                        ndata2.push(completo2)
                        ndata2.push(penS2)
                        ndata2.push(penP2)
                    }
                    setData3(ndata2);
                }
            })

            fetch(`http://localhost:5000/data?fecha1=${dateInit}&fecha2=${dateFin}`)
            .then(response => response.json())
            .catch(error => console.error(error))
            .then(data => {
                var ndata = []
                    for (var j = 0; j < data.length; j++){
                        var completo = { total: data[j].Tiempo_Trabajo, init: "", end: "", name:"Trabajo" }
                        var penS = { total: (data[j].Penalizacion_No_S/60), init: "", end: "", name:"Sentado" }
                        var penP = { total: (data[j].Penalizacion_No_P/60), init: "", end: "", name:"Parado" }
                        ndata.push(completo)
                        ndata.push(penS)
                        ndata.push(penP)
                    }
                    setData4(ndata);
            })
            

    }, 1000);

    return (
        <div>
            <p className="fs-5 text-end"> <span className="fw-bold text-end">Usuario:</span> {getUser()}</p>
            <div style={{ width: "95%", margin: "auto", marginTop: "5%", marginBottom: "5%" }}>
                <center><h1>INFORME EN TIEMPO REAL</h1></center>
                <form style={{ width: "30%", margin: "auto", marginTop: "3%" }} onSubmit={handleSubmit}>
                    <div className="mb-3">
                        <label className="form-label">Inicio:</label>
                        <input type="date" className="form-control" defaultValue={dateInit} />
                    </div>
                    <div className="mb-3">
                        <label className="form-label">Fin:</label>
                        <input type="date" className="form-control" defaultValue={dateFin}/>
                    </div>
                    <center><button type="submit" className="btn btn-primary">Establecer datos</button></center>
                </form>
                <div className="container" style={{ marginTop: "5%" }}>
                    <div className="row">
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Penalización por no sentarse a tiempo </h4>
                            <BarChart data={data1} name="Penalización (s)" color="red" color2="black" />
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4> Penalización por no pararse a tiempo</h4>
                            <BarChart data={data2} name="Penalización (s)" color="red" color2="black"/>
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Validación de que el usuario esté sentado </h4>
                            <center><img src={img} alt="Imagen" style={{ maxWidth: "100%", maxHeight: "100%", ...imgStyle1 }} /></center>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Validación de que el usuario no esté sentado</h4>
                            <center><img src={img2} alt="Imagen" style={{ maxWidth: "100%", maxHeight: "100%", ...imgStyle2 }} /></center>
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Porcentajes de cumplimiento</h4>
                            <BarChart data={data3} name="Cumplimiento (%)" color="green" color2="#FF0000" color3="#760000" />
                        </div>
                        <div className="col-md-4 col-sm-6 box">
                            <h4>Gráfica del total de pomodoros</h4>
                            <BarChart data={data4} name="Pomodoros (min)" color="green" color2="#FF0000" color3="#760000"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    );
}

export default Graficas;